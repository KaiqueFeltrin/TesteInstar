import sqlite3

conn = sqlite3.connect('meubanco.db')
cur  = conn.cursor()

print("=== Clientes com pedidos > que R$100 ===")
cur.execute("""
    SELECT DISTINCT c.id, c.nome, c.email
    FROM clientes c
    JOIN pedidos p ON c.id = p.id_cliente
    WHERE p.total > 100
    ORDER BY c.nome;
""")
for row in cur.fetchall():
    print(row)

print("\n=== Total de pedidos por cliente ===")
cur.execute("""
    SELECT c.id, c.nome, COUNT(p.id) AS total_pedidos
    FROM clientes c
    LEFT JOIN pedidos p ON c.id = p.id_cliente
    GROUP BY c.id, c.nome;
""")
for row in cur.fetchall():
    print(row)

conn.close()

