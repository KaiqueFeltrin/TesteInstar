import sqlite3

conn = sqlite3.connect('meubanco.db')
cursor = conn.cursor()

print("Clientes cadastrados:")
for row in cursor.execute("SELECT * FROM clientes"):
    print(row)

print("\nPedidos realizados:")
for row in cursor.execute("SELECT * FROM pedidos"):
    print(row)

conn.close()

