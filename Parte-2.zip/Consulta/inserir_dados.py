import sqlite3

conn = sqlite3.connect('meubanco.db')
cursor = conn.cursor()

cursor.execute("""
INSERT INTO clientes (nome, email) 
VALUES
    ('João Paulo', 'joao.paulo@email.com'),
    ('Kaique Feltrin', 'kaique.feltrin@email.com')
""")

cursor.execute("""
INSERT INTO pedidos (id_cliente, data, total) 
VALUES
    (4, '2023-04-15 10:30:00', 120.50),
    (4, '2023-04-16 11:45:00', 85.00),
    (6, '2023-04-17 14:00:00', 150.00),
    (6, '2023-04-17 16:30:00', 200.00)
""")
conn.commit()
conn.close()

print("Dados inseridos com sucesso!")
