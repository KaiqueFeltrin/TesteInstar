import sqlite3

conn = sqlite3.connect('meubanco.db')
cursor = conn.cursor()

cursor.execute('''
CREATE TABLE clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT,
    email TEXT
)
''')

cursor.execute('''
CREATE TABLE pedidos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_cliente INTEGER,
    data TEXT,
    total REAL,
    FOREIGN KEY(id_cliente) REFERENCES clientes(id)
)
''')

conn.commit()
conn.close()
