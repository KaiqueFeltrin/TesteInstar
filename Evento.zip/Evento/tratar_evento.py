import json
from datetime import datetime

def tratar_evento(evento):
    for chave in ["nome", "sobrenome", "titulo"]:
        if chave in evento and isinstance(evento[chave], str):
            evento[chave] = evento[chave].replace("NBSP", " ").strip()

    data_br = evento["dataRealizacao"]
    data_obj = datetime.strptime(data_br, "%d/%m/%Y %H:%M:%S")
    data_sql = data_obj.strftime("%Y-%m-%d %H:%M:%S")
    evento["dataRealizacao"] = data_sql

    data_formatada_br = data_obj.strftime("%d/%m/%Y")
    hora_formatada = data_obj.strftime("%H:%M:%S")
    evento["titulo"] = evento["titulo"].replace("...", data_formatada_br, 1)
    evento["titulo"] = evento["titulo"].replace("...", hora_formatada, 1)

    if "descricao" in evento and isinstance(evento["descricao"], list):
        evento["descricao"] = " ".join(evento["descricao"])


    if "arquivos" in evento:
        for arquivo in evento["arquivos"]:
            if "data" in arquivo:
                data_arq_obj = datetime.strptime(arquivo["data"], "%d/%m/%Y")
                arquivo["data"] = data_arq_obj.strftime("%Y-%m-%d %H:%M:%S")

            chaves_remover = [k for k, v in arquivo.items() if v is None]
            for chave in chaves_remover:
                del arquivo[chave]

    # Remover nulos no evento principal
    chaves_remover_evento = [k for k, v in evento.items() if v is None]
    for chave in chaves_remover_evento:
        del evento[chave]

    return evento


with open('evento.json', 'r', encoding='utf-8') as arquivo:
    dados = json.load(arquivo)

dados_tratados = [tratar_evento(evento) for evento in dados]

with open('evento_tratado.json', 'w', encoding='utf-8') as arquivo_saida:
    json.dump(dados_tratados, arquivo_saida, indent=4, ensure_ascii=False)

print("Arquivo tratado com sucesso!")
